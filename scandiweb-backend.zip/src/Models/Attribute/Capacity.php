<?php

namespace Jamesdencorrea\ScandiwebBackend\Models\Attribute;

use Jamesdencorrea\ScandiwebBackend\Models\Attribute;

class Capacity extends Attribute
{
    public function getType(): string
    {
        return 'capacity';
    }
}
