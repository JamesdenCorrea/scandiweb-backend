<?php

require_once __DIR__ . '/../src/Controller/GraphQL.php';

Jamesdencorrea\ScandiwebBackend\Controller\GraphQL::handle();
